class Book(
    title: String,
    avtor: String,
    yearDate: Int,
    pages: Int
): BookManager(title, avtor, yearDate, pages) {
}