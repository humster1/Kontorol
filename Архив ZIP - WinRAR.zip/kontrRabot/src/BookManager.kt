abstract class BookManager(
    val title: String,
    val avtor: String,
    val yearDate: Int,
    val pages: Int
) {
override fun toString(): String{
    return "Книга $title от автора $avtor выпущена $yearDate, $pages страниц"
}
}