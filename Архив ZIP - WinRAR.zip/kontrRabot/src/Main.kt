import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

interface BookMain {
    fun addNewBook(book: Book);
  fun removeBook(book: Book);
    fun bookName(title: String): Book?
     fun setAllBook(): List<Book>
}


fun main() {
    val bookManager = BookSetting()
    val name: String
    val fioAvtor: String
    val year: Int
    val page: Int

    println("Здравствуйте! Какую книгу вы хотите добавить?")
    print("Напишите ее название: ")
    name = readLine()!!
    if (name >= "a" || name <= "я" || name >= "a" || name <= "z") {

        print("Кто ее автор? Напишите его/ее ФИО: ")
        fioAvtor = readLine()!!

        if (fioAvtor >= "a" || fioAvtor <= "я" || fioAvtor >= "a" || fioAvtor <= "z") {
            print("Когда она была выпущена: ")
            year = readLine()!!.toInt()

            if(year in 1000..2023){
                print("Сколько в ней страниц: ")
                    page = readLine()!!.toInt()
                if(page in 10..5000){

                    println("Добавляю книгу с задержкой....")
                    Thread.sleep(1500)
                    bookManager.addNewBook(Book("$name", "$fioAvtor", year, page))
                    println()

                    println("Добавляю книгу")
                    runBlocking {
                        launch {
                            delay(900)
                            bookManager.addNewBook(Book("$name", "$fioAvtor", year, page))
                        }
                    }
                    println()

                    print("Все книги в продаже: ")
                    bookManager.setAllBook().forEach { println(it) }
                } else println("Ошибка ввода!")
            } else println("Ошибка ввода!")

        } else println("Ошибка ввода!")

    }


}



