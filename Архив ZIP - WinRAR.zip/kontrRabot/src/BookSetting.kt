open class BookSetting: BookMain {
    private val books = mutableListOf<Book>()

    override fun addNewBook(book: Book) {
        books.add(book)
        println("Добавлена книга $book")
    }

    override fun removeBook(book: Book) {
        books.remove(book)
        println("Удалена книга $book")
    }

    override fun bookName(title: String): Book? {
        return books.find { it.title == title }
    }

    override fun setAllBook(): List<Book> {
        return books.toList()
    }
}